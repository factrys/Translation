package com.factrys.translation;

import cn.nukkit.plugin.PluginBase;
import java.util.List;

public class Loader extends PluginBase {
    private static String DELAULT_LANGUAGE;
    private static List<String> ALL_LANGUAGES;

    @Override
    public void onEnable() {
        DELAULT_LANGUAGE = this.getConfig().getString("default");
        ALL_LANGUAGES = this.getConfig().getStringList("languages");
        this.saveDefaultConfig();
    }

    public static List<String> getAllLanguages() {
        return ALL_LANGUAGES;
    }

    public static String getDefaultLanguage() {
        return DELAULT_LANGUAGE;
    }
}