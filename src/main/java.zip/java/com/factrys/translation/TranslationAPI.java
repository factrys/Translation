package com.factrys.translation;

import cn.nukkit.Player;
import cn.nukkit.utils.Config;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class TranslationAPI {
    private final Map<String, Config> translations = new HashMap<>();

    public void builds(File dataFolder) {
        List<String> languages = Loader.getAllLanguages();
        for (String language : languages) {
            File langFile = new File(dataFolder, language + ".json");
            Config langConfig = new Config(langFile, Config.JSON);
            translations.put(language, langConfig);
        }
    }

    public String translate(String language, String key) {
        if (!translations.containsKey(language)) {
            language = Loader.getDefaultLanguage();
        }

        Config langConfig = translations.get(language);
        return langConfig.getString(key, key);
    }

    public String translate(Player player, String key) {
        String language = player.getLanguageCode().toString();
        return translate(language, key);
    }
}